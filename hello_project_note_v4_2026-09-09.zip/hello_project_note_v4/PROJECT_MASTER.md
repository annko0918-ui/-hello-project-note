# Hello! Project Note — Project Master v4

## 目的
「今日のハロプロを、1ページで。」を核にした非公式情報ポータル。
公式ニュース、Ameba公式ブログ、出演予定、リリースを日付順に追いやすくし、
検索流入と毎日のリピート訪問を両方伸ばす。

## 現行サイトで残すもの
- 既存のタイムライン
- ニュース / ブログ / リリース / イベント絞り込み
- キーワード検索
- メンバー絞り込み
- 日付絞り込み
- お気に入り
- グループページ
- 出演カレンダー
- 外部公式リンク
- 非公式サイト・権利帰属表記

## v4で追加・改善するもの
1. トップの3導線
   - 今日・今週の出演予定
   - 推しから探す
   - 最新タイムライン
2. 「今週のハロプロ」をタイムラインの上へ
3. `/members/` メンバー一覧
4. 各メンバー個別ページの固有H1/title/description/canonical
5. カレンダーの直近7日を初期HTMLへ出す
6. sitemap.xml / robots.txt
7. 0件・空見出し・読み込み前ダッシュ表示の改善

## UI原則
- 今の紙面 / 雑誌 / エディトリアル感を維持
- 白ではなく温かい紙色
- 太い黒、細い罫線、控えめな赤
- 写真だけに依存しない
- スマホ390pxを最優先
- タップ領域44px目安
- AIっぽい丸カード乱立は避ける

## データ原則
- 本文転載はしない
- タイトル、日時、メンバー、グループ、外部URL、公開サムネイルなど必要最小限
- 取得失敗時は直前の成功データを表示
- JST基準
- 公式スケジュール / 公式ニュースを優先
- sitemapは実在ルートだけ

## SEO title
- Top: ハロプロノート｜今日のブログ・ニュース・出演情報
- Members: ハロプロ メンバー一覧｜グループ別に探す｜ハロプロノート
- Group: <グループ> 最新ブログ・ニュース・出演情報｜ハロプロノート
- Member: <メンバー> 最新ブログ・ニュース・出演情報｜<グループ>｜ハロプロノート

## 次の実装順
P0: `/members/`、トップ3導線、今週予定、meta/canonical
P1: カレンダー初期HTML、メンバー個別SEO、sitemap
P2: Search Console / Analytics、人気ページ、検索クエリ分析
P3: セトリDB、ブログ横断検索、通知系

## 収益化
広告はUXを壊さない位置のみ。
まず検索・リピートを育て、その後AdSense / 物販系アフィリエイトを検討。


## v4 design refinement
- Top page should feel like one editorial stream, not a dashboard.
- Keep the hero compact on mobile.
- Put schedule immediately after status.
- Move utility shortcuts into a slim navigation rail.
- Keep current timeline visually dominant.
- Add a mobile bottom nav only under 640px.
