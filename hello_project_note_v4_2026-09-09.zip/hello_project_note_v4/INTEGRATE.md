# 既存サイトへ統合するときの指示

このフォルダは独立デモ＋統合パッチ。

## まず反映
1. assets/site.css のデザインを既存CSSへ必要分だけ統合
2. partials/home_integration.html の3導線＋今週予定を既存heroとタイムラインの間に追加
3. members/index.html を `/members/` として追加
4. data/members.json をメンバーの単一ソースにする
5. seo/robots.txt / seo/sitemap.xml を公開ルートへ

## 既存サイト側と接続
- トップの数値 `—` は既存記事JSONから「JSTの今日」の件数をbuild時に埋める
- 「今週のハロプロ」は既存カレンダーデータから今日〜7日後を最大10〜20件静的生成
- デモの `demo_articles.json` と `schedule_snapshot...json` は本番では使わない
- 既存のお気に入りlocalStorageキーが別にある場合は site.js のキーを既存キーへ揃える
- 既存タイムラインは削除しない

## QA
- 390pxで横スクロールなし
- キーワード/メンバー/日付/種別フィルタが維持
- お気に入り維持
- `/members/` の全リンクが200
- `/calendar/` のHTMLソースに直近予定が存在
- title/description/canonicalがページ固有
- robots/sitemapが200


## v4補足
- `partials/home_integration_v4.html` を優先して使う。
- v4では3つの大きいカードではなく、細い3導線に変更。現行トップとの馴染みを優先。
- モバイルのみ下部3タブを表示可能。既存ヘッダーが十分なら省略可。
