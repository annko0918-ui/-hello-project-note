const HPN = (() => {
  const favKey = 'hello-project-note-favorite-members-v1';

  function readFavs(){
    try { return new Set(JSON.parse(localStorage.getItem(favKey) || '[]')); }
    catch { return new Set(); }
  }
  function writeFavs(set){ localStorage.setItem(favKey, JSON.stringify([...set])); }
  function syncFavButtons(){
    const favs = readFavs();
    document.querySelectorAll('[data-fav-member]').forEach(btn => {
      const name = btn.dataset.favMember;
      const on = favs.has(name);
      btn.classList.toggle('on', on);
      btn.textContent = on ? '♥' : '♡';
      btn.setAttribute('aria-label', `${name}を${on ? 'お気に入りから外す' : 'お気に入りに追加'}`);
    });
  }
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-fav-member]');
    if(!btn) return;
    const favs = readFavs(), name = btn.dataset.favMember;
    favs.has(name) ? favs.delete(name) : favs.add(name);
    writeFavs(favs); syncFavButtons();
  });
  document.addEventListener('DOMContentLoaded', syncFavButtons);
  return { readFavs, syncFavButtons };
})();
