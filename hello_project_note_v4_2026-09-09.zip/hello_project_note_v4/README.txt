Hello! Project Note v3

開くもの:
- index.html : 次版トップページのスタンドアロンデモ
- members/index.html : メンバー一覧デモ
- PROJECT_MASTER.md : このプロジェクトの基準仕様
- INTEGRATE.md : 現行サイトへの統合手順

デモデータについて:
- data/demo_articles.json は現行サイトの表示内容から作った見た目確認用
- data/schedule_snapshot_2026-09-09.json は公式スケジュールの見た目確認用
- 本番では既存の自動取得データへ接続する

メンバー:
- data/members.json は2026-09-09時点でハロー！プロジェクト公式Artistページを照合
